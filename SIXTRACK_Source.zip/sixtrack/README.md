# SIXTRACK – Group Expense Manager

A Flutter Android expense tracker for Praveen, Mohan, Balaji, Kavi, Bala and Aravind.

## Features
- Offline SQLite database with persistent expenses and member allocations.
- Add, view, edit, duplicate and delete expenses.
- Equal, custom amount and percentage splits.
- Member balances and suggested settlements.
- Dashboard KPIs and charts based on stored records.
- Search, multi-filtering, date ranges and sorting.
- PDF report generation, print and share.
- JSON backup and restore.
- Dark/light theme.
- GitHub Actions APK build.

## Run locally
Install Flutter stable, then:

```bash
flutter pub get
flutter create --platforms=android .
flutter run
```

## Build APK
```bash
flutter build apk --release
```

Or push this repository to GitHub and open **Actions → Build SIXTRACK APK → Run workflow**.
Download the generated `SIXTRACK-Android-APK` artifact.

## Mobile-only build
1. Create a GitHub repository in your phone browser.
2. Extract this ZIP on your phone.
3. Upload the extracted project contents (not the enclosing folder) to the repository.
4. Open Actions and run **Build SIXTRACK APK**.
5. Download the artifact ZIP, extract it, then install `app-release.apk`.

## Data and backup
All records are stored locally on the device. They are not automatically synchronized between phones. Use Settings → Export JSON Backup and import the backup on another device when needed.

## Settlement logic
For each expense, the payer receives a credit equal to the full amount and each participant receives a debit equal to their allocated share. The net member balance is paid minus allocated. Positive balances are owed money; negative balances owe money. Suggested settlements are calculated from these net balances.
